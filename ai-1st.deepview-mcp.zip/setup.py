"""
Setup script for the deepview-mcp package.
This file is needed for compatibility with setuptools.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
