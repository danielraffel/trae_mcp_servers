# Goal

Help me thoroughly test this server's functionality.

## Requirements

- [x] Test `get_cards_by_list_id` tool
- [x] Test `get_lists` tool
- [ ] Test `get_recent_activity` tool
- [ ] Test `add_card_to_list` tool
- [ ] Test `update_card_details` tool
- [ ] Test `archive_card` tool
- [ ] Test `add_list_to_board` tool
- [ ] Test `archive_list` tool
- [ ] Test `get_my_cards` tool