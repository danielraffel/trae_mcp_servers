import { log } from 'apify';

log.setLevel(log.LEVELS.DEBUG);

export { log };
