// Configuration
export const CONFIG = {
  serverName: "notion-mcp-server",
  serverVersion: "1.0.0",
};
