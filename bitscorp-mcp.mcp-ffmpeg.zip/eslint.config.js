import neostandard from 'neostandard'

export default neostandard({
  ignores: ['node_modules', 'dist']
})
